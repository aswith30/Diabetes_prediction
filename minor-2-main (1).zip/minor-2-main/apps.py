from django.apps import AppConfig


class DiabetesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'diabetes_app'
